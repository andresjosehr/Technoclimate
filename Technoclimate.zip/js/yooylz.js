do ->
  footer = '<footer id="footer" role="contentinfo">
      <div class="container">
        <h3 class="footer-title">
          <a href="https://codepen.io/collection/XRoxGR" target="_blank">Calibration template</a>
        </h3>
        <p class="footer-entry">
          <a href="https://mobilemarkup.com" target="_blank">mobileMarkup.com</a>
        </p>
      </div>
    </footer>'  
  document.body.insertAdjacentHTML 'beforeend', footer